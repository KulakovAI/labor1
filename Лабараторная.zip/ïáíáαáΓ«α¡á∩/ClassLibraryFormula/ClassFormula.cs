﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryFormula
{
    public class ClassFormula
    {
        public double FormulaR(double a, double x, double b)
	    {
			double R = Math.Round(x * x * (x + 1) / b - Math.Pow(Math.Sin(x + a), 2), 5);
			return R;
	    }
		public double FormulaS(double a, double x, double b)
		{
			double S = Math.Round(Math.Sqrt(x * b / a) + Math.Pow(Math.Cos(x + b), 2), 5);
			return S;
		}
	}
}
