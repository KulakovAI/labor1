﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ClassLibraryFormula;

namespace UnitTestProjectFormula
{
    [TestClass]
    public class UnitTestFormula
    {
        [TestMethod]
        public void R1_Formula_07and05and005__6_63130314222938returned()
        {
            double a = 0.7;
            double x = 0.5;
            double b = 0.05;
            double expected = 6.63130;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S1_Formula_07and05and005__0915780297217402returned()
        {
            double a = 0.7;
            double x = 0.5;
            double b = 0.05;
            double expected = 0.91578;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void R2_Formula_0and0and1__0returned()
        {
            double a = 0;
            double x = 0;
            double b = 1;
            double expected = 0;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S2_Formula_1and0and0__1returned()
        {
            double a = 1;
            double x = 0;
            double b = 0;
            double expected = 1;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void R3_Formula_1and1and1__1returned()
        {
            double a = 1;
            double x = 1;
            double b = 1;
            double expected = 1.17318;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S3_Formula_1and1and1__1returned()
        {
            double a = 1;
            double x = 1;
            double b = 1;
            double expected = 1.17318;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }
    }
}
  
       